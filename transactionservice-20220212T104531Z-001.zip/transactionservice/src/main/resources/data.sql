INSERT INTO TRANSACTION(id, source_Account_Id,source_Owner_Name,target_Account_Id,target_Owner_Name,amount,initiation_Date,reference)
VALUES (1, 10054546,'Paul Dragoslav', 10054546, 'Paul Dragoslav', 100.00, '2019-04-01 10:30', 'transfer');

