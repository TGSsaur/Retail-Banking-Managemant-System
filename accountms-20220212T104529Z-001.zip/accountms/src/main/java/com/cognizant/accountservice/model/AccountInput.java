package com.cognizant.accountservice.model;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountInput {
	
	/**
	 *  Class used for inputing account info during transaction
	 */
	
	@NotNull(message = "Account number is mandatory")
	private long accountId;
	@NotNull(message = "Amount is mandatory")
	private double amount;
	public AccountInput(@NotNull(message = "Account number is mandatory") long accountId,
			@NotNull(message = "Amount is mandatory") double amount) {
		super();
		this.accountId = accountId;
		this.amount = amount;
	}
	public AccountInput() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
}