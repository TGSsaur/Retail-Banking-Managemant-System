INSERT INTO ACCOUNT(account_Id,customer_Id,current_Balance,account_Type,owner_Name)
VALUES (10054546,'CUSTOMER101',1071.78, 'Savings', 'Paul Dragoslav');

INSERT INTO ACCOUNT(account_Id,customer_Id,current_Balance,account_Type,owner_Name)
VALUES (65544168, 'CUSTOMER102', 67051.01, 'Current', 'Scrooge McDuck');
