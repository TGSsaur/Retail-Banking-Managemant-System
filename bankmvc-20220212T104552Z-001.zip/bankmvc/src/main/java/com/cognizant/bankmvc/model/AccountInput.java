package com.cognizant.bankmvc.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class AccountInput {
	private long accountId;
	private double amount;
	public AccountInput(long accountId, double amount) {
		super();
		this.accountId = accountId;
		this.amount = amount;
	}
	public AccountInput() {
		super();
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}

	
}