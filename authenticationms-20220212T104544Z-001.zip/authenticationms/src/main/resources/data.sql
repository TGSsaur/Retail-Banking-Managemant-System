insert into appuser (userid,username,password,role) values ('EMPLOYEE101','emp','emp','EMPLOYEE');
insert into appuser (userid,username,password,role) values ('CUSTOMER101','cust','cust','CUSTOMER');
