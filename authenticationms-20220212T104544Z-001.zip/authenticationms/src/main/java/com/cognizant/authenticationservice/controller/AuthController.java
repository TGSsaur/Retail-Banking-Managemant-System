package com.cognizant.authenticationservice.controller;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.authenticationservice.exceptionhandling.AppUserNotFoundException;
import com.cognizant.authenticationservice.model.AppUser;
import com.cognizant.authenticationservice.model.AuthenticationResponse;
import com.cognizant.authenticationservice.repository.UserRepository;
import com.cognizant.authenticationservice.service.LoginService;
import com.cognizant.authenticationservice.service.Validationservice;

import lombok.extern.slf4j.Slf4j;


/**
 * Authorization micro-service controller class to map all authorization based request raised by other microservice
 *
 */
@Slf4j
@RestController
public class AuthController {
	
	private static final Logger log = LoggerFactory.getLogger(AuthController.class);

	
	
	
	//Validation Service bean
	@Autowired
	private Validationservice validationService;
	
	//Login Service bean
	@Autowired
	private LoginService loginService;
		
	
	// H2 Repository 
	@Autowired
	private UserRepository userRepository;
	
	

	/**
	 * Login form with post request
	 *
	 */
	@PostMapping("/login")
	public ResponseEntity<AppUser> login(@RequestBody AppUser appUserloginCredentials) throws UsernameNotFoundException, AppUserNotFoundException {
		AppUser user = loginService.userLogin(appUserloginCredentials);
		log.info("Credentials ----->{}",user);
		return new ResponseEntity<>(user , HttpStatus.ACCEPTED);
	}
	
	
	/**
	 * Creating User and adding it to h2 database using userRepository Instance
	 *
	 */
	@PostMapping("/createUser")
	public ResponseEntity<?> createUser(@RequestBody AppUser appUserInput)
	{
		AppUser newUser = null;
		try {
			newUser = userRepository.save(appUserInput);
		}
		catch(Exception e)
		{
			return new ResponseEntity<String>("User Creation Failed" , HttpStatus.NOT_ACCEPTABLE);
		}
		log.info("user under creation---->{}",newUser);
		return new ResponseEntity<>(newUser,HttpStatus.CREATED);
		
	}
	/**
	 * Mapping Method to validate Token
	 *
	 */
	@GetMapping("/validateToken")
	public AuthenticationResponse getValidity(@RequestHeader("Authorization") final String token) {
		log.info("Token Validation ----->{}",token);
		return validationService.validate(token);
	}
	
	
	
	/**
	 * Employee accessible method to find all user HAVING EMPLOYEE role
	 *
	 */
	@PreAuthorize("hasRole('ROLE_EMPLOYEE')")
	@GetMapping("/find")
	public ResponseEntity<List<AppUser>> findUsers(@RequestHeader("Authorization") final String token)
	{
		List<AppUser> findAllUser = userRepository.findAll();
		List<AppUser> newUser =new ArrayList<>() ;
		
		findAllUser.forEach(emp->newUser.add(emp));
		log.info("All Users  ----->{}",findAllUser);
		return new ResponseEntity<>(newUser,HttpStatus.CREATED);
		
	}
	/**
	 * Method to get role by having id
	 * @param id
	 * @return
	 */
	@GetMapping("/role/{id}")
	public String getRole(@PathVariable("id") String id) {
		return userRepository.findById(id).get().getRole();
	}
	

	
	/**
	 * Status Checking of application
	 *
	 */
	@GetMapping("/health")
	public ResponseEntity<String> healthCheckup() {
		log.info("Health Status for Authentication Microservice");
		log.info("health checkup ----->{}","up");
		return new ResponseEntity<>("UP", HttpStatus.OK);
	}
	
}