package com.cognizant.authenticationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * The Application to start the Authentication microservice 
 *
 */
@SpringBootApplication
@EnableSwagger2
public class AuthenticationMsApplication {
	

	
	/**
	 * main method running start from this point
	 */
	public static void main(String[] args) {
		SpringApplication.run(AuthenticationMsApplication.class, args);
	}

}
 