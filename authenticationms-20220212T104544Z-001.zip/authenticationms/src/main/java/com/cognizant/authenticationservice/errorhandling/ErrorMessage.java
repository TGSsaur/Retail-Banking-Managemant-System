package com.cognizant.authenticationservice.errorhandling;
import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

/**
 * Error message class to handle all error related to authentication microservices
 * @author Saurabh
 *
 */
public class ErrorMessage 
{
    
	private String message;
    private LocalDateTime timestamp;
    
    private HttpStatus status;
    
    
	//Default Constructor
    public ErrorMessage() {
		super();
		// TODO Auto-generated constructor stub
	}
    //Constructor with field
	public ErrorMessage(HttpStatus status, LocalDateTime timestamp, String message) {
		super();
		this.status = status;
		this.timestamp = timestamp;
		this.message = message;
	}
	// Getter and Setter
	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
    
    
}