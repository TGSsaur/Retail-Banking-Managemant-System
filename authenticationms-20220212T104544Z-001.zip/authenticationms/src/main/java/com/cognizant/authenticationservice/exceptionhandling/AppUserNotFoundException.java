package com.cognizant.authenticationservice.exceptionhandling;

//Class for APPUSER is not found in DB
public class AppUserNotFoundException extends Exception 
{
	/**
	*
	*
	* Exception in case of invalid user
	*/
	private static final long serialVersionUID = 1L;
	
	public AppUserNotFoundException() 
	{
		super();
		//Empty Constructor
	}

	public AppUserNotFoundException(final String mssg) 
	{
		//Constructor for AppUserNotFoundException
		super(mssg);
	}
}