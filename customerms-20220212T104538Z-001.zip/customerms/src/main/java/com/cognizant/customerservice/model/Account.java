package com.cognizant.customerservice.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Transient;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Account {
	
	

	private long accountId;

	private String customerId;


	private double currentBalance;

	private String accountType;

	private String ownerName;

	@Transient
	private List<Transaction> transactions = new ArrayList<>();

	public Account(long accountId, String customerId, double currentBalance, String accountType, String ownerName,
			List<Transaction> transactions) {
		super();
		this.accountId = accountId;
		this.customerId = customerId;
		this.currentBalance = currentBalance;
		this.accountType = accountType;
		this.ownerName = ownerName;
		this.transactions = transactions;
	}

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}
	
	

}