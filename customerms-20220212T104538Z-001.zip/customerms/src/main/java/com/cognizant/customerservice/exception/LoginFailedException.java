package com.cognizant.customerservice.exception;

public class LoginFailedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
